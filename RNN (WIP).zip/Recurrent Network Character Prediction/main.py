import codecs
import random
import numpy as np
import math
words = []
word_number = {}
words_with_repeats = []
with codecs.open('Harry Potter.txt', encoding='utf-8') as f:
    for line in f:
        new_words = line[:-2].split()
        for i in range(len(new_words)):
            word = new_words[i]
            word = word.replace('‘','\'').replace('’','\'').strip('\".;:?!-–…,\'()').lower()
            new_words[i] = word + ''
            words_with_repeats.append(word)
        for word in new_words:
            if word not in words and word != '':
                words.append(word)
                word_number[word] = 1
            elif word != '':
                word_number[word] += 1




chars = []
for word in words:
    for char in word:
        if char not in chars: chars.append(char)
total  = sum([word_number[word] for word in words])
N = len(chars)  # size of input and output vectors
M = 10          # size of hidden layer
                # note that cranking M too large can decrease performance,
                # or at least increase number of iterations required to converge
                # though this may depend on the size of the const variable

def rand_word():
    n = random.randint(1,total)
    for word in words:
        n -= word_number[word]
        if n <= 0:
            return word

def soft_max(v):
    v = np.exp(v)
    v = v/np.sum(v)
    return v

def vectorise(word):
    v = []
    for char in word:
        cv = np.zeros((N,1))
        cv[chars.index(char)] = 1
        v.append(cv)
    return v

def vectorise_with_bias(word):
    v = []
    for char in word:
        cv = np.zeros((N+1,1))
        cv[chars.index(char)] = 1
        cv[N] = 1
        v.append(cv)
    return v

def sig(v):
    return 0.5 + 0.5*np.tanh(0.5*v)

##h = []
##y = []
##n = len(x)-1
##h.append(np.tanh(np.dot(A,x[0])))
##y.append(sig(np.dot(C,h[0])))
##for i in range(1,n):
##    h.append(np.tanh(np.dot(A,x[i])+np.dot(B,h[i-1])))
##    y.append(sig(np.dot(C,h[i])))

A = np.random.randn(M,N+1)# input into hidden layer matrix
B = np.random.randn(M,M)# previous hidden layer to next hidden layer matrix
C = np.random.randn(N,M)# hidden layer into output matrix
const = 1500
losses = []
ONLY_ONE_LOOP = False
for j in range(1000):
    total_loss = 0
    dAL = np.zeros((M,N+1))
    dBL = np.zeros((M,M))
    dCL = np.zeros((N,M))
    skip_counter = 0
    """for i in range(3*const):
        /word = rand_word()[:-1]"""
    for word in words_with_repeats:
        if len(word) < 3:
            skip_counter += 1
            continue
        x = vectorise_with_bias(word[:-1])    # input layer at each stage
        h = []                      # hidden layer at each stage
        y = []                      # output layer at each stage
        n = len(x)-1
        target_y = vectorise(word[1:])
        h.append(np.tanh(np.dot(A,x[0])))
        y.append(sig(np.dot(C,h[0])))
        for i in range(1,n):
            h.append(np.tanh(np.dot(A,x[i])+np.dot(B,h[i-1])))
            y.append(sig(np.dot(C,h[i])))
        
        """z=2*(y[n-1]-target_y[n-1]).reshape((N))
        L = z@z/4   # loss"""
        z = []
        L = 0
        for m in range(n):
            z.append(2*(y[m]-target_y[m]).reshape((N)))
            L += z[m]@z[m]/4
        total_loss += L
        
        """t = np.dot(np.expand_dims(np.identity(N),2),h[n-1].T)
        dCy = (y[n-1]-y[n-1]*y[n-1])*t
        dCL += np.tensordot(z,dCy,1)""" # primitive loss version
        dCy = np.zeros((N,N,M))
        for m in range(n):
            t = np.dot(np.expand_dims(np.identity(N),2),h[m].T)
            dCy = (y[m]-y[m]*y[m])*t
        for m in range(n):
            dCL += np.tensordot(z[m],dCy[m],1)
                
        hh = []
        for m in range(n):
            hh.append(B*(1-h[m]*h[m]))
        Ah = []
        for m in range(n):
            Ah.append(np.tensordot(np.expand_dims(np.identity(M)*(1-h[m]*h[m]),2),x[m].T,1))
        Bh = [np.zeros((M,M,M))]
        for m in range(1,n):
            Bh.append(np.tensordot(np.expand_dims(np.identity(M)*(1-h[m]*h[m]),2),h[m-1].T,1))
        dAh = [Ah[0]]
        for m in range(1,n):
            dAh.append(Ah[m]+np.tensordot(hh[m],dAh[m-1],1))
        dBh = [np.zeros((M,M,M))]
        for m in range(1,n):
            dBh.append(Bh[m]+np.tensordot(hh[m],dBh[m-1],1))
        t = C*(y[n-1]-y[n-1]*y[n-1])

        """dAy = np.tensordot(t,dAh[n-1],1)    # primitve loss version
        dAL += np.tensordot(z,dAy,1)"""
        dAy = []                                                    # backpropagation
        for m in range(n):                                          # for loss across
            dAy.append(np.tensordot(C*(y[m]-y[m]*y[m]),dAh[m],1))   # whole output
        for m in range(n):
            dAL += np.tensordot(z[m],dAy[m],1)
        
        
        """dBy = np.tensordot(t,dBh[n-1],1)    # primitve loss version
        dBL += np.tensordot(z,dBy,1)"""
        dBy = []                                                    #
        for m in range(n):                                          # likewise
            dBy.append(np.tensordot(C*(y[m]-y[m]*y[m]),dBh[m],1))   #
        for m in range(n):
            dBL += np.tensordot(z[m],dBy[m],1)

        if ONLY_ONE_LOOP: break
        
    dAL /= const
    dBL /= const
    dCL /= const
##    if j < 20:
##        c = 6
##    elif j < 80:
##        c = 3
##    else:
##        c = 1
    c = 1
    dAL *= c
    dBL *= c
    dCL *= c
    A -= dAL    # dAL could be wrong?
    B -= dBL    # dBL seems right
    C -= dCL    # dCL seems right
    print(total_loss)
    losses.append(total_loss)
    if ONLY_ONE_LOOP: break

total_chars = 0
accurate_chars = 0
null_chars = 0
range_total = 0
for i in range(10000):
    word = rand_word()[:-1]

    if len(word) < 3:
        skip_counter += 1
        continue
    x = vectorise_with_bias(word[:-1])    # input layer at each stage
    h = []                      # hidden layer at each stage
    y = []                      # output layer at each stage
    n = len(x)-1
    total_chars += n
    target_y = vectorise(word[1:])
    h.append(np.tanh(np.dot(A,x[0])))
    y.append(sig(np.dot(C,h[0])))
    for m in range(1,n):
        h.append(np.tanh(np.dot(A,x[m])+np.dot(B,h[m-1])))
        y.append(sig(np.dot(C,h[m])))
    for m in range(n):
        j = np.argmax(y[m])
        if j != None:
            if chars[j] == word[m]:
                accurate_chars += 1
                #print(word)
        else:
            null_chars += 1
        range_total += np.ndarray.max(y[m]) - np.ndarray.min(y[m])
print(accurate_chars/total_chars*100)
print(null_chars/total_chars*100)
print(range_total/total_chars)

