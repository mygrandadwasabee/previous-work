"""

This is the module GUI.py, and it's mostly recycled from a previous programming
project, although I have made changes for this project. This is also written for
Python 3, but can work with python 2 if the "##"s are removed from:
##DEFAULT_RESOLUTION = [1280,720] # if using python 2
##resolution = [1280,720]


"""


import pygame
pygame.init()
pygame.font.init()
clock = pygame.time.Clock()

##DEFAULT_RESOLUTION = [1280,720] # if using python 2
##resolution = [1280,720]

BRIGHTGREY = (195,195,195)
BLACK = (0,0,0)
WHITE = (255,255,255)
BLUE = (0,0,200)
BRIGHTBLUE = (0,0,255)
DARKGREEN = (0,100,0)
GREEN = (0,200,0)
BRIGHTGREEN = (0,255,0)
DARKRED = (100,0,0)
RED = (200,0,0)
BRIGHTRED = (255,0,0)
ORANGE = (225, 110, 0)
BRIGHTORANGE = (255, 120, 0)
TURQUOISE = (0,162,232)
BRIGHTTURQUOISE = (0,179,255)
DARKTURQUOISE = (0,118,168)
LIGHTPINK = (255,200,200)


display = None

def set_display(Display):
    global display
    display = Display

def Round(n):       # in case using python 2
    return int(n)+int(n-int(n)>=0.5)

def true():
    return True

def false():
    return False

def check_click_and_escape(events):
    # check if escape was pressed or left-mouse-button
    Break = False
    click = False
    for event in events:
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                Break = True
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                click = True
    return click, Break

def draw_button(x_res_multiplier,y_res_multiplier,X,Y,Width,Height,text,click=False,colour=TURQUOISE,activeColour=BRIGHTTURQUOISE,func=true,textSize=55,textColour=BRIGHTGREY,selected_colour=DARKGREEN,selected=False,disabled=False):
    x=Round(X*x_res_multiplier);width=Round(Width*x_res_multiplier)
    y=Round(Y*y_res_multiplier);height=Round(Height*y_res_multiplier)
    # adjust button size to fit aspect screen resolution
    mousex, mousey = pygame.mouse.get_pos()
    if x < mousex < x + width and y < mousey < y + height and not disabled:
        # so mouse is hovering over button
        # enlarge button slightly (for aesthetic)
        if selected:
            blit_button(selected_colour,x,y,width,height)
        else:
            width += 4
            height += 4
            x -= 2
            y -= 2
            blit_button(activeColour,x,y,width,height)
        if click:
            message_display(x_res_multiplier,y_res_multiplier,X,Y,Width,Height,text,textSize,textColour)
            return func()
            # do button's function if button clicked (and return result)
    else:
        if selected:
            blit_button(selected_colour,x,y,width,height)
        else:
            blit_button(colour,x,y,width,height)
    message_display(x_res_multiplier,y_res_multiplier,X,Y,Width,Height,text,textSize,textColour)
    # put text in button

def draw_triangle_button(x_res_multiplier,y_res_multiplier,x,y,width,height,pointing_right=True,colour=TURQUOISE,activeColour=BRIGHTTURQUOISE,mouse_clicked=False,func=true,active=True):
    x=Round(x*x_res_multiplier);width=Round(width*x_res_multiplier)
    y=Round(y*y_res_multiplier);height=Round(height*y_res_multiplier)
    Bool = False
    mousex, mousey = pygame.mouse.get_pos()
    n = 1
    if not pointing_right:
        x = x + width
        width = -width
        n = -1
    if not active:
        colour = DARKTURQUOISE
    vertices1 = ((x,y),(x+width,Round(y+height/2)),(x,y+height))
    vertices2 = ((x+1,y+1),(x+width-1,Round(y+height/2)),(x+1,y+height-1))
    if (mousey > y+(height-float((x+width)*height)/width)/2 + float(height)/(2*width)*mousex and
        mousey < y+(height+float((x+width)*height)/width)/2 - float(height)/(2*width)*mousex and
        ((mousex > x and pointing_right) or (mousex < x and not pointing_right))) and active:
        width += 4*n
        height += 4
        x -= 2*n
        y -= 2
        colour = activeColour
        if mouse_clicked:
            Bool = True
    vertices1 = ((x,y),(x+width,Round(y+height/2)),(x,y+height))
    vertices2 = ((x+n,y+2),(x+width-n,Round(y+height/2)),(x+n,y+height-2))
    pygame.draw.polygon(display,colour,vertices1,0)
    pygame.draw.polygon(display,BRIGHTGREY,vertices2,1)
    return Bool
    

def blit_button(colour,x,y,width,height,line_colour=BRIGHTGREY):
    pygame.draw.rect(display, colour, (x, y, width, height))
    pygame.draw.line(display, line_colour, (x+1, y+1), (x-2+width, y+1))
    pygame.draw.line(display, line_colour, (x+1, y+height-2), (x-2+width, y+height-2))
    pygame.draw.line(display, line_colour, (x+1, y+1), (x+1, y+height-2))
    pygame.draw.line(display, line_colour, (x+width-2, y+1), (x+width-2, y+height-2))

def text_objects(text,font,colour):
    TextSurface = font.render(text, True, colour)
    return TextSurface, TextSurface.get_rect()

def message_display(x_res_multiplier,y_res_multiplier,x,y,width,height,text,text_size=60,centred=True,colour=BRIGHTGREY,spacing=5,text_font="freesansbold.ttf"):
    text_size = Round(text_size*min(x_res_multiplier,y_res_multiplier))
    x=Round(x*x_res_multiplier);width=Round(width*x_res_multiplier)
    y=Round(y*y_res_multiplier);height=Round(height*y_res_multiplier)
    if text == str(text):
        text = [text]
    x2,y2=x+width,y+height
    line_size = text_size + spacing
    text_box_size = line_size * len(text)
    text_box_start = (y + y2 - text_box_size + line_size)/2
    for i in range(0,len(text)):
        largeText = pygame.font.Font("freesansbold.ttf",text_size)
        TextSurf, TextRect = text_objects(text[i], largeText, colour)
        if centred:
            TextRect.center = (width)/2 + x, text_box_start + line_size * i
            display.blit(TextSurf, TextRect)
        else:
            display.blit(TextSurf,(x,y))

"""
END OF ESSENTIALS
"""

def confirm(message):
    screenshot = pygame.PixelArray(display).make_surface()
    screenshot.convert()
    x_mult = resolution[0]/DEFAULT_RESOLUTION[0]
    y_mult = resolution[1]/DEFAULT_RESOLUTION[1]
    while True:
        display.fill(BLACK)
        click, escape = check_click_and_escape(pygame.event.get())
        if escape:
            return False
        screenshot.set_alpha(50)
        display.blit(screenshot,(0,0))
        message_display(x_mult,y_mult,330,200,620,100,message)
        if draw_button(x_mult,y_mult,320,400,300,100,"Yes",click):
            return True
        elif draw_button(x_mult,y_mult,660,400,300,100,"No",click):
            return False
        pygame.display.update()
        clock.tick(30)

def take_input():
    # this will be useful
    while True:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                return event.key


def update_text(text,events,number=False,length_limit=None,text_size=None):
    acceptable_characters = ["-",",",".","'"]
    if number:
        acceptable_characters = ["."]
    for event in events:
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_BACKSPACE:
                if len(text) > 0:
                    text = text[0:-1]
            elif event.key == pygame.K_SPACE:
                text += " "
            else:
                char = pygame.key.name(event.key)
                if len(char) == 1 and (char.isalpha() and not number or char.isdigit() or (char in acceptable_characters and (not number or char not in text))):
                    if pygame.key.get_pressed()[303] or pygame.key.get_pressed()[304]:
                        text += char.upper()
                    else:
                        text += char.lower()
    if length_limit != None:
        TextSurface = pygame.font.Font("freesansbold.ttf",text_size).render(text,True,BLACK)
        while TextSurface.get_width() > length_limit:
            text = text[:-1]
            TextSurface = pygame.font.Font("freesansbold.ttf",text_size).render(text,True,BLACK)
    return text


def check_enter(events):
    for event in events:
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                return True


def help_button(click):
    should_launch_menu = False
    centre = (29,resolution[1]-30)
    mouse_pos = pygame.mouse.get_pos()
    r = 20
    colour = TURQUOISE
    if (mouse_pos[0]-centre[0])**2+(mouse_pos[1]-centre[1])**2 < 400:
        if click:
            should_launch_menu = True
        colour = BRIGHTTURQUOISE
        r = 22
    pygame.draw.circle(display,colour,centre,r)
    pygame.draw.circle(display,BRIGHTGREY,centre,r-1,1)
    message_display(1,1,9,resolution[1]-48,40,40,"i",text_size=30)
    if should_launch_menu:
        info_menu()

def info_menu():
    while True:
        x_mult = resolution[0]/DEFAULT_RESOLUTION[0]
        y_mult = resolution[1]/DEFAULT_RESOLUTION[1]
        click, escape = check_click_and_escape(pygame.event.get())
        display.fill(BLACK)
        message_display(x_mult,y_mult,0,-50,DEFAULT_RESOLUTION[0],DEFAULT_RESOLUTION[1],[  "This program is intended to highlight the inaccuracies of the 2-body physics model in comparison to the N-body physics model.",
                                                                                         "The 2-body model takes into account only an object and the body it orbits around, whereas the N-body model takes into account",
                                                                                         "the gravitational influence of every object with mass. The N-body model is therefore generally more accurate, so all movement of",
                                                                                         "planets, moons, etc. is calculated this way. However, you can select an object to see a line showing the 2-body prediction of its",
                                                                                         "orbital path, and compare this with the actual path the object takes under the N-body model.","",""
                                                                                         "Using this program:","",
                                                                                         "When in a simulation, you can navigate around by clicking and dragging to pan the view, and by scrolling to,",
                                                                                         "zoom in/out (this can also be done using the UP and DOWN arrow keys by default, for laptop users)","",
                                                                                         "Left-clicking on an object sets the camera to follow it, right-clicking brings up orbital information",
                                                                                         "and the editing menu. Right-clicking will also display an orbital prediction based on the 2-body model","",
                                                                                         "New objects can be added to the simulation using MIDDLE MOUSE button, although laptop users can use the",
                                                                                         "INSERT key by default (near the delete key)","",
                                                                                         "Pressing ESCAPE (by default) will open the Simulation Menu if already in a simulation.",
                                                                                         "Pressing SPACE (by default) will pause time, and the </> keys slow down and speed up time by default,",
                                                                                         "respectively. Key bindings can be changed to your personal preference in the controls menu (in options)","",
                                                                                         "Changing the \"calculation rate\" in the simulation menu improves accuracy of the simulation but takes more",
                                                                                         "processing power. This info guide can be brought back up by pressing the \"i\" button in the bottom left"],text_size=18,text_font="freesans.ttf")
        if escape or draw_button(x_mult,y_mult,500,620,280,60,"Okay",click,textSize=35):
            break
        pygame.display.update()
        clock.tick(30)

    
