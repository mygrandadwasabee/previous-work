"""

This is evidence of the program for the extended project. The program is built to run in
Python 3 with pygame, however it can be made to run with python 2 by removing the "##" from
"##GUI.set_display(display) # only if using python 2". There is another module, GUI.py,
which is also written by me and required for this to run, which will also be attached.


"""



import pygame
from math import *
import cmath
import GUI
import random
import os
import time
pygame.init()

##GUI.set_display(display) # only if using python 2

# defining colour values
BRIGHTGREY = (195,195,195)
BLACK = (0,0,0)
WHITE = (255,255,255)
BLUE = (0,0,200)
BRIGHTBLUE = (0,0,255)
DARKGREEN = (0,100,0)
GREEN = (0,200,0)
BRIGHTGREEN = (0,255,0)
DARKRED = (100,0,0)
RED = (200,0,0)
BRIGHTRED = (255,0,0)
ORANGE = (225, 110, 0)
BRIGHTORANGE = (255,120,0)
TURQUOISE = (0,162,232)
BRIGHTTURQUOISE = (0,179,255)
DARKTURQUOISE = (0,118,168)
LIGHTPINK = (255,200,200)

PLANET_COLOURS = [WHITE,BLUE,BRIGHTBLUE,DARKGREEN,GREEN,BRIGHTGREEN,DARKRED,RED,BRIGHTRED,ORANGE,BRIGHTORANGE,TURQUOISE,BRIGHTTURQUOISE,DARKTURQUOISE,LIGHTPINK]
SUN_COLOURS = [WHITE,DARKRED,RED,BRIGHTRED,ORANGE,BRIGHTORANGE,TURQUOISE,BRIGHTTURQUOISE]

DEFAULT_DISPLAY_WIDTH = 1280
DEFAULT_DISPLAY_HEIGHT = 720
GUI.DEFAULT_RESOLUTION = [DEFAULT_DISPLAY_WIDTH,DEFAULT_DISPLAY_HEIGHT]

display_width = 1280
display_height = 720
GUI.resolution = [display_width,display_height]

display = pygame.display.set_mode((display_width, display_height))
GUI.display = display
pygame.display.set_caption("Orbital Simulation")
clock = pygame.time.Clock()

G = 6.67408e-11
# gravitational constant
MASS_OF_EARTH = 5.972358737084362e24
MASS_OF_SUN = 1.988468822669192e30


def draw_trajectory(trajectory,display,zoom,offset,is_ellipse):
    if trajectory != None:
        # to draw a trajectory from an array of points in absolute space
        # (so panning and zooming doesn't change the input trajectory)
        point_array = trajectory[0]
        # trajectory = [point_array, parent_body]
        if is_ellipse: stop_point = -1  # so ellipse is closed
        else:
            stop_point = 0              # so hyperbola is left open-ended 
            for i in [1,-1]:
                p1 = ((point_array[i][0]+trajectory[1].pos[0])/zoom+offset[0],
                      (point_array[i][1]+trajectory[1].pos[1])/zoom+offset[1])
                p2 = ((point_array[i-1][0]+trajectory[1].pos[0])/zoom+offset[0],
                      (point_array[i-1][1]+trajectory[1].pos[1])/zoom+offset[1])
                # p1 and p2 are the last two points on one of the asymtopes
                m = (p1[1]-p2[1])/(p1[0]-p2[0])
                c = p1[1]-m*p1[0]
                try:
                    if (p1[0] < p2[0] and i == 1) or (p1[0] > p2[0] and i == -1):
                        pygame.draw.aaline(display,WHITE,p2,(display_width,m*display_width+c))
                    else:
                        pygame.draw.aaline(display,WHITE,p1,(0,c))
                except: pass
                # this extends the line of the asymtope to avoid calculating
                # lots of points earlier on
        for i in range(len(point_array)-1,stop_point,-1):
            p1 = ((point_array[i][0]+trajectory[1].pos[0])/zoom+offset[0],
                  (point_array[i][1]+trajectory[1].pos[1])/zoom+offset[1])
            p2 = ((point_array[i-1][0]+trajectory[1].pos[0])/zoom+offset[0],
                  (point_array[i-1][1]+trajectory[1].pos[1])/zoom+offset[1])
            try:
                pygame.draw.aaline(display,WHITE,p1,p2)
            except: pass
            # literally dot-to-dot


def magnitude(x,y): # find magnitude of a vector
    return (x**2+y**2)**0.5

class celestial_body:
    # class for all celestial objects

    def __init__(self,data_package):
        self.GM = data_package[0]
        self.pos = data_package[1]      # in 1000km
        self.vel = data_package[2]      # in 1000km
        self.name = data_package[3]
        self.colour = data_package[4]
        self.r = data_package[5]
        self.is_daddy = False
        self.e = 0

    def simulate_tick(self,time,i):
        # simulate one very short period of time
        for parent in self.priorities1:
            self.simulate_interaction(parent,time)
        if i % 5 == 0:
            for parent in self.priorities2:
                self.simulate_interaction(parent,time*5)
            if i % 20 == 0:
                for parent in self.priorities3:
                    self.simulate_interaction(parent,time*20)
            if i % 50 == 0:
                for parent in self.priorities4:
                    self.simulate_interaction(parent,time*50)
        self.pos = [self.pos[0]+self.vel[0]*time, self.pos[1]+self.vel[1]*time]
        

    def simulate_interaction(self,parent,time_duration):
        x_difference = parent.pos[0]-self.pos[0]
        y_difference = parent.pos[1]-self.pos[1]
        try:
            rest_of_equation = magnitude(x_difference,y_difference)**(-3)*parent.GM*time_duration
        except: rest_of_equation = 0
        self.vel[0] += x_difference*rest_of_equation
        self.vel[1] += y_difference*rest_of_equation
        # apply acceleration from that specific body

    def calculate_priority(self,target):
        r, theta1 = cmath.polar(complex(self.pos[0]-target.pos[0],self.pos[1]-target.pos[1]))
        v, theta2 = cmath.polar(complex(self.vel[0]-target.vel[0],self.vel[1]-target.vel[1]))
        gamma = fabs(theta1 - theta2)
        try:
            value = fabs(v*sin(gamma)*r**(-3)*(target.GM+self.GM))
        except:
            value = 0
        return value

    def calculate_priorities(self):
        self.priorities1 = []
        self.priorities2 = []
        self.priorities3 = []
        self.priorities4 = []
        
        for body in bodies:
            if body.name != self.name:
                arg=self.calculate_priority(body)
                if arg > 2e-15:
                    self.priorities1.append(body)
                elif arg > 1e-16:
                    self.priorities2.append(body)
                elif arg > 1e-18:
                    self.priorities3.append(body)
                else:
                    self.priorities4.append(body)

    def draw(self,display,zoom,offset):
        centre = (Round(self.pos[0]/zoom+offset[0]),Round(self.pos[1]/zoom+offset[1]))
        # centre of circle
        radius = max(Round(self.r/zoom)+1,4)
        if 0 <= centre[0]+radius and centre[0]-radius < display_width:
            if 0 <= centre[1]+radius and centre[1]-radius < display_height:
                try:
                    pygame.draw.circle(display,self.colour,centre,radius)
                except: pass
                    

    def parent_body(self):  # to find an object's parent body
        if not self.is_daddy:
            parent = bodies[-1]
            # start out with some parent to compare to
            for body in bodies:
                if body.name != self.name and body.GM >= self.GM:
                    if body.GM > parent.GM:
                        if self.distance_from(parent) > body.distance_from(parent)*(parent.GM/body.GM)**0.4:
                            parent = body
                    elif self.distance_from(body) < body.distance_from(parent)*(body.GM/parent.GM)**0.4 and self.distance_from(body) < self.distance_from(parent):
                        parent = body
                    # using SOI calculation
            return parent

    def distance_from(self,Object):
        return magnitude(self.pos[0]-Object.pos[0],self.pos[1]-Object.pos[1])

    def get_orbital_elements(self):
        # updates orbital elements and returns them (maybe redundant?)
        if not self.is_daddy:
            self.update_orbital_elements(self.parent_body())
            return self.a, self.e, self.longitude_of_periapsis

    def calculate_orbital_velocity(self):
        if not self.is_daddy:
            parent =  self.parent_body()
            rel_vel = (self.vel[0]-parent.vel[0],self.vel[1]-parent.vel[1])
            return magnitude(rel_vel[0],rel_vel[1])

    def update_orbital_elements(self,parent):
        if not self.is_daddy:
            # based on the two-body model
            total_GM = parent.GM + self.GM
            # this becomes important when mass of parent and mass of
            # orbiting body are close
            rel_coords = (self.pos[0]-parent.pos[0],self.pos[1]-parent.pos[1])
            rel_vel = (self.vel[0]-parent.vel[0],self.vel[1]-parent.vel[1])
            r = magnitude(rel_coords[0],rel_coords[1])
            # distance between parent and object
            v = magnitude(rel_vel[0],rel_vel[1])
            # velocity relative to parent
            try:
                self.a = 1/(2/r-v*v/total_GM)
            except: self.a = r*1e10
            # semi-major axis
            theta1 = cmath.phase(complex(rel_coords[0],rel_coords[1])) % (pi*2)
            theta2 = cmath.phase(complex(rel_vel[0],rel_vel[1])) % (pi*2)
            gamma = fabs(theta1 - theta2)
            # angle between velocity and displacement vector
            if gamma > pi:
                gamma = pi*2 - gamma
            try:
                apsis = self.a*(1+sqrt(1-v**2*r**2*sin(gamma)**2/total_GM/self.a))
            except: apsis = self.a
            # could be periapsis or apoapsis? Did both cases just in case:
            if apsis >= self.a or apsis < 0:
                self.e = apsis/self.a - 1
            else:
                self.e = 1 - apsis/self.a
            try:
                nu = acos(((self.a*(1-self.e**2)/r)-1)/self.e)
            except:
                # floating point slippage could cause math domain error in acos()
                try:
                    if ((self.a*(1-self.e**2)/r)-1)/self.e < -1:
                        nu = pi
                    else:
                        nu = 0
                except:
                    nu = 0
            if (theta2 - theta1) % (pi*2) < pi:
                # if motion is clockwise
                nu = 2*pi - nu
            if gamma > pi/2:
                # because x=acos(theta) doesn't distinguish
                # between 0 < x < pi and pi < x < tau
                nu = 2*pi - nu
            self.longitude_of_periapsis = (nu+theta1) % (pi*2)

    def get_trajectory(self):
        if not self.is_daddy:
            parent = self.parent_body()
            points = []
            # an array to store points from a hyopthetical graph representing the
            # trajectory, with co-ordinates relative to that hypothetical graph

            if self.e < 1:
                # so orbit is elliptical
                b = self.a*sqrt(1-self.e**2)
                # semi-minor axis
                try:
                    dist_from_o = sqrt(self.a**2-b**2)
                except:
                    dist_from_o = self.a
                # distace from parent body to origin of a hypothetical graph
                o_rel_to_parent = (-dist_from_o*cos(self.longitude_of_periapsis),
                                   -dist_from_o*sin(self.longitude_of_periapsis))
                
                # origin of the hypothetical graph's co-ordinates in absolute space
                # relative to the parent body's position
                for x in range(0,Round(self.a*sqrt(3)/2),Round(self.a/250+1)):
                    try:
                        y = -b*sqrt(1-(x/self.a)**2)
                        points.append((x,y))
                    except:break
                # generate points of the ellipse from segments along the major axis
                for y in range(Round(-b/2),1,Round(b/250)+1):
                    try:
                        x = self.a*sqrt(1-(y/b)**2)
                        points.append((x,y))
                    except:pass
                # generate points of the ellipse from sgements along the minor axis
                # (both techniques used so that the curve stays more smooth)

                for i in range(len(points)-1,-1,-1):
                    points.append((points[i][0],-points[i][1]))            
                for i in range(len(points)-1,-1,-1):
                    points.append((-points[i][0],points[i][1]))
                    # creating other half of ellipse
                    # done in reverse order so that a continuous line through the
                    # co-ordinates of the array in order will not cut acorss any points


            elif self.e > 1:
                # so orbit is a hyperbola
                periapsis = self.a*(1-self.e)
                dist_from_o = periapsis + fabs(self.a)
                # distace from parent body to origin of a hypothetical graph
                b = sqrt(dist_from_o**2-self.a**2)
                # semi-minor axis
                o_rel_to_parent = (dist_from_o*cos(self.longitude_of_periapsis),
                                   dist_from_o*sin(self.longitude_of_periapsis))
                # origin of the hypothetical graph's co-ordinates in absolute space
                # relative to the parent body's position
                points.append((9*self.a,-9*b))
                points.append((8.5*self.a,-8.5*b))
                # one asymptope of the hyperbola's points added
                for y in range(Round(-b*4),Round(b*4),Round(b/125)+1):
                    # there will always be 1000 plotted points distributed
                    # linearly along the quadruple of the minor axis
                    x = self.a*sqrt(1+(y**2)/(b**2))
                    points.append((x,y))
                    # calculating points for said hypothetical graph 
                points.append((8.5*self.a,8.5*b))
                points.append((9*self.a,9*b))
                # other asymptope of the hyperbola's points added

            transformed_points = []
            # an array to store points for the trajectory, with co-ordinates
            # relative to absolute space

            for point in points:
                rotated_point = complex(point[0],point[1])*cmath.exp(complex(0,self.longitude_of_periapsis))
                # rotating points by multiplying by e^(i*theta)
                transformed_points.append((rotated_point.real+o_rel_to_parent[0],
                                           rotated_point.imag+o_rel_to_parent[1]))
                # translating rotated points so they are now relative to
                # absolute space rather than the hypothetical graph

            return transformed_points, parent


def Round(n):       # in case using python 2
    return int(n)+int(n-int(n)>=0.5)


def generate_new_name():
    n = 0
    while True:
        for body in bodies:
            if body.name == "New body #" + str(n):
                n += 1
                break
        else:
            return "New body #" + str(n)


def number_to_string(n,should_add_commas_or_standard_form=True):
    # to make numbers into easily readable strings
    if (n >= 1e10 or n < 1e-3) and should_add_commas_or_standard_form:
        power = int(log10(n))
        n = float(n)/(10**power)
        if n < 1:
            n *= 10
        n = format(n, '.3g')
        # convert number to standard form, 3 s.f.
        return n + "*10^" + str(power)
    if Round(n) == n or (n > 1e5 and not should_add_commas_or_standard_form):
        n = str(Round(n))
    elif "e" in str(n):
        if n < 1:
            power = -int(log10(n))
            return "0."+"0"*power+str(round(n*10**(power+4)))
    else:
        n, decimal = str(n).split(".")
    # store number as int if it represents and 
    # int or separate into integer and decimal
    if len(n) > 3 and should_add_commas_or_standard_form:
        new_n = ""
        for i in range(len(n)-1,-1,-1):
            new_n = n[i] + new_n
            if (len(n)-i) % 3 == 0 and i != 0:
                new_n = "," + new_n
        return new_n
        # add commas into integer part to separate thousands
    if len(n) < 5:
        try:
            decimal;return format(float(n+"."+decimal),'.5g')
        except: pass
    return n
    # format to 5 s.f. or the nearest integer


def format_time(time):  # to convert time to appropriate units
    units = (("minutes",60),("hours",60),("days",24),("years",365.25))
    unit = "seconds"
    for i in range(len(units)):
        new_time = time/units[i][1]
        if new_time > 1:
            # so big enough to be reasonable in this unit
            time = new_time
            unit = units[i][0]
        else:
            break
    return number_to_string(time)+" "+unit


def format_mass(GM):
    mass = GM/G * 10**18
    return number_to_string(mass)+"kg"


def load_file(file):    # function to load data about celestial objects from a .txt
    celestial_objects = []
    lines = open(file,"r").readlines()
    for line in lines:
        line = line.strip("\n")
        if line == "NEW CELESTIAL BODY":
            # signifies an entry for a new celestial body
            celestial_objects.append([])
            # until the end, new objects will be treated as the arguments which
            # should be entered when defining them as a celestial_body object
        elif line == "END":
            for i in range(len(celestial_objects)):
                try:
                    celestial_objects[i] = celestial_body(celestial_objects[i])
                    # convert each list of arguments to a celestial_body object
                except:
                    print("ERROR INITIALIZING celestial_body OBJECT")
        elif line != "":
            try:
                celestial_objects[-1].append(eval(line))
            except:
                print("ERROR : SAVE FILE SYNTAX ERROR")
                print("Problem at +\""+line+"\"")
                while 1:pass
    return celestial_objects


def save(File):    # function to save data about celestial objects to a .txt
    File = open(File,"w")
    string = ""
    for body in bodies:
        string += "NEW CELESTIAL BODY\n"
        string += str(body.GM)+"\n"
        string += str(body.pos)+"\n"
        string += str(body.vel)+"\n"
        string += "\""+body.name+"\"\n"
        string += str(body.colour)+"\n"
        string += str(body.r)+"\n\n"
        # add information about each body to the string, separated by
        # "NEW CELESTIAL BODY" and an empty line
    string += "END"
    File.write(string)
    File.close()


def save_controls(controls):
    File = open("Saves/Controls.txt","w")
    for mapping in controls:
        File.write(str(mapping[1])+"\n")
    File.close()


def load_controls():
    global global_controls
    File = open("Saves/Controls.txt","r").readlines()
    i = 0
    keys = []
    for line in File:
        if line != "":
            keys.append(line.strip("\n"))
    try:
        for i in range(len(global_controls)):
            global_controls[i][1] = int(keys[i])
    except: print("Error loading controls")


def main_menu():
    while True:
        x_mult = display_width/DEFAULT_DISPLAY_WIDTH
        y_mult = display_height/DEFAULT_DISPLAY_HEIGHT
        click, escape = GUI.check_click_and_escape(pygame.event.get())
        display.fill(BLACK)
        GUI.message_display(x_mult,y_mult,330,60,620,100,"Main Menu")
        should_start = GUI.draw_button(x_mult,y_mult,330,230,620,100,"Start",click)
        should_go_to_options = GUI.draw_button(x_mult,y_mult,330,360,620,100,"Options",click)
        if GUI.draw_button(x_mult,y_mult,330,490,620,100,"Quit",click):
            pygame.quit()
            quit()
        GUI.help_button(click)
        pygame.display.update()
        clock.tick(30)

        if should_start:
            start_info = start()
            if start_info[0]:
                return start_info[1], start_info[2]
        elif should_go_to_options:
            options(pygame.Surface((display_width,display_height)))


def start():
    x_mult = display_width/DEFAULT_DISPLAY_WIDTH
    y_mult = display_height/DEFAULT_DISPLAY_HEIGHT
    count = 0
    while True:
        click, escape = GUI.check_click_and_escape(pygame.event.get())
        if escape:
            return False, None
        display.fill(BLACK)
        GUI.message_display(x_mult,y_mult,330,60,620,100,"Start")
        should_start_new_sim = GUI.draw_button(x_mult,y_mult,330,230,620,100,"New Simulation",click)
        should_load_prev_sim = GUI.draw_button(x_mult,y_mult,330,360,620,100,"Load Previous",click)
        if GUI.draw_button(x_mult,y_mult,330,490,620,100,"Back to Main Menu",click):
            return False, None
        if count > 0:
            count -= 1
            GUI.message_display(x_mult,y_mult,330,124,620,100,"No free slots",text_size=35)
        GUI.help_button(click)
        pygame.display.update()
        clock.tick(30)

        if should_start_new_sim:
            start_info = new_simulation()
            if start_info[0]:
                return True, start_info[1], True
            elif start_info[1] == "No free slots":
                count = 30
        elif should_load_prev_sim:
            start_info = load_simulation()
            if start_info[0]:
                return True, start_info[1], False


def new_simulation():
    if len(os.listdir("Saves/Personal")) > 4:
        return False, "No free slots"
    x_mult = display_width/DEFAULT_DISPLAY_WIDTH
    y_mult = display_height/DEFAULT_DISPLAY_HEIGHT
    string = ""
    count = 0
    while True:
        events = pygame.event.get()
        click, escape = GUI.check_click_and_escape(events)
        if escape:
            return False, None
        string = GUI.update_text(string,events,length_limit=620*x_mult,text_size=55)
        display.fill(BLACK)
        GUI.message_display(x_mult,y_mult,330,60,620,100,"New Simulation")
        if count > 0:
            count -= 1
            GUI.message_display(x_mult,y_mult,330,124,620,100,"Invalid name",text_size=35)
        GUI.message_display(x_mult,y_mult,0,250,620,100,"Name Simulation:")
        GUI.draw_button(x_mult,y_mult,620,250,620,100,string,click,colour=BLACK,disabled=True)
        if GUI.draw_button(x_mult,y_mult,210,420,400,100,"Done",click) or GUI.check_enter(events):
            valid = string != ""
            for existing_file_name in os.listdir("Saves/Personal"):
                valid = valid and string+".txt" != existing_file_name
            if valid:
                return True, "Saves/Personal/"+string+".txt"
            else:
                count = 30
        if GUI.draw_button(x_mult,y_mult,670,420,400,100,"Cancel",click):
            return False, None
        GUI.help_button(click)
        pygame.display.update()
        clock.tick(30)


def load_simulation():
    personal = os.listdir("Saves/Personal")
    presets = os.listdir("Saves/Presets")
    x_mult = display_width/DEFAULT_DISPLAY_WIDTH
    y_mult = display_height/DEFAULT_DISPLAY_HEIGHT
    while True:
        click, escape = GUI.check_click_and_escape(pygame.event.get())
        display.fill(BLACK)
        GUI.message_display(x_mult,y_mult,330,60,620,100,"Load Which Simulation?")
        should_delete = GUI.draw_button(x_mult,y_mult,1040,70,200,80,"Delete",click,RED,BRIGHTRED)
        for i in range(5):
            try:
                if GUI.draw_button(x_mult,y_mult,100,180+100*i,500,80,personal[i].strip(".txt"),click,textSize=45):
                    return True, "Saves/Personal/"+personal[i]
            except:
                GUI.draw_button(x_mult,y_mult,100,180+100*i,500,80,"--empty--",click,textSize=45)
        for i in range(4):
            if GUI.draw_button(x_mult,y_mult,680,180+100*i,500,80,presets[i].strip(".txt"),click,textSize=45,disabled=presets[i].strip(".txt")=="--coming soon--"):
                return True, "Saves/Presets/"+presets[i]
        if GUI.draw_button(x_mult,y_mult,680,580,500,80,"Back",click):
            return False, None
        GUI.help_button(click)
        pygame.display.update()
        clock.tick(30)

        if should_delete:
            delete_menu()
            personal = os.listdir("Saves/Personal")
            presets = os.listdir("Saves/Presets")


def delete_menu():
    personal = os.listdir("Saves/Personal")
    presets = os.listdir("Saves/Presets")
    x_mult = display_width/DEFAULT_DISPLAY_WIDTH
    y_mult = display_height/DEFAULT_DISPLAY_HEIGHT
    while True:
        item_deleted = False
        click, escape = GUI.check_click_and_escape(pygame.event.get())
        display.fill(BLACK)
        GUI.message_display(x_mult,y_mult,330,60,620,100,"Click Slot to be Deleted")
        should_break = GUI.draw_button(x_mult,y_mult,1040,70,200,80,"Delete",click,DARKRED,DARKRED)
        for i in range(5):
            try:
                if GUI.draw_button(x_mult,y_mult,100,180+100*i,500,80,personal[i].strip(".txt"),click,textSize=45):
                    item_deleted = i+1
            except:
                GUI.draw_button(x_mult,y_mult,100,180+100*i,500,80,"--empty--",click,textSize=45)
        for i in range(4):
            GUI.draw_button(x_mult,y_mult,680,180+100*i,500,80,presets[i].strip(".txt"),click,DARKTURQUOISE,disabled=True,textSize=45)
        if GUI.draw_button(x_mult,y_mult,680,580,500,80,"Back",click):
            break
        GUI.help_button(click)
        pygame.display.update()
        clock.tick(30)

        if item_deleted != False:
            if GUI.confirm("Are you sure?"):
                os.remove("Saves/Personal/"+personal[item_deleted-1])
                break
        elif should_break:
            break


def options(screenshot):
    global fps
    global resolution
    global display_width
    global display_height
    global display
    RESOLUTIONS = []
    res_change = 0
    while True:
        display.fill(BLACK)
        should_change_res = False
        x_mult = display_width/DEFAULT_DISPLAY_WIDTH
        y_mult = display_height/DEFAULT_DISPLAY_HEIGHT
        right_act, left_act = True, True
        right_act2, left_act2 = True, True
        if fps == len(framerates)-1: right_act = False
        elif fps == 0: left_act = False
        if resolution+res_change == len(resolutions)-1: right_act2 = False
        elif resolution+res_change == 0: left_act2 = False
        click, escape = GUI.check_click_and_escape(pygame.event.get())
        display.blit(screenshot,(0,0))
        if escape:
            break
        GUI.message_display(x_mult,y_mult,330,60,620,100,"Options Menu")
        should_go_to_controls = GUI.draw_button(x_mult,y_mult,330,200,620,100,"Controls",click)
        GUI.draw_button(x_mult,y_mult,330,320,620,100,"Resolution: "+str(resolutions[resolution+res_change][0])+"x"+str(resolutions[resolution+res_change][1]),click,disabled=True)
        if GUI.draw_triangle_button(x_mult,y_mult,980,320,70,100,True,mouse_clicked=click,active=right_act2):
            res_change += 1
        if GUI.draw_triangle_button(x_mult,y_mult,230,320,70,100,False,mouse_clicked=click,active=left_act2):
            res_change -= 1
        if res_change != 0:
            if GUI.draw_button(x_mult,y_mult,1080,340,150,60,"Apply",click,textSize=45):
                resolution += res_change
                display_width = resolutions[resolution][0]
                display_height = resolutions[resolution][1]
                GUI.resolution = [display_width,display_height]
                should_change_res = True
        GUI.draw_button(x_mult,y_mult,330,440,620,100,"FPS: "+str(framerates[fps]),disabled=True)
        if GUI.draw_triangle_button(x_mult,y_mult,980,440,70,100,True,mouse_clicked=click,active=right_act):
            fps += 1
        if GUI.draw_triangle_button(x_mult,y_mult,230,440,70,100,False,mouse_clicked=click,active=left_act):
            fps -= 1
        should_go_back = GUI.draw_button(x_mult,y_mult,330,560,620,100,"Back",click)
        GUI.help_button(click)
        pygame.display.update()
        clock.tick(30)

        if should_change_res:
            display = pygame.display.set_mode((display_width, display_height))
            GUI.display = display
            res_change = 0
        if should_go_back:
            break
        elif should_go_to_controls:
            global global_controls
            global_controls = controls(screenshot)


def controls(screenshot):
    new_controls = list(global_controls)
    x_mult = display_width/DEFAULT_DISPLAY_WIDTH
    y_mult = display_height/DEFAULT_DISPLAY_HEIGHT
    while True:
        clicked_key = None
        click, escape = GUI.check_click_and_escape(pygame.event.get())
        display.blit(screenshot,(0,0))
        if escape:
            break
        GUI.message_display(x_mult,y_mult,330,60,620,100,"Controls")
        for i in range(5):
            GUI.draw_button(x_mult,y_mult,100,180+100*i,300,80,new_controls[i][0],click,textSize=40,disabled=True)
        for i in range(5,9):
            if len(new_controls[i][0]) == 2:
                GUI.draw_button(x_mult,y_mult,680,180+100*(i-5),300,80,new_controls[i][0],click,textSize=30,disabled=True)
            else:
                GUI.draw_button(x_mult,y_mult,680,180+100*(i-5),300,80,new_controls[i][0],click,textSize=40,disabled=True)
        for i in range(9):
            if i >= 5:
                if GUI.draw_button(x_mult,y_mult,1000,180+100*(i-5),180,80,pygame.key.name(new_controls[i][1]).upper(),click,textSize=36):
                    clicked_key = i
            else:
                if GUI.draw_button(x_mult,y_mult,420,180+100*i,180,80,pygame.key.name(new_controls[i][1]).upper(),click,textSize=36):
                    clicked_key = i
        should_save_changes = GUI.draw_button(x_mult,y_mult,680,580,240,80,"Accept",click,textSize=50)
        should_cancel = GUI.draw_button(x_mult,y_mult,940,580,240,80,"Cancel",click,textSize=50)
        if clicked_key != None:
            still = pygame.PixelArray(display).make_surface().convert()
            display.fill(BLACK)
            still.set_alpha(50)
            display.blit(still,(0,0))
            name = new_controls[clicked_key][0]
            if len(name[0]) != 1:
                name = name[0]
            GUI.message_display(x_mult,y_mult,330,270,620,100,["Press any key to change","\""+name+"\" button"],spacing=20)
            pygame.display.update()
            new_controls[clicked_key] = [new_controls[clicked_key][0],GUI.take_input()]
        GUI.help_button(click)
        pygame.display.update()
        clock.tick(30)

        if should_cancel:
            return global_controls
        elif should_save_changes:
            save_controls(new_controls)
            return new_controls


def pause():
    screenshot = pygame.PixelArray(display).make_surface()
    timer, save_message = 0, ""
    global simulation_speed
    speed_name = ["very low","low","normal","high","very high"]
    while True:
        x_mult = display_width/DEFAULT_DISPLAY_WIDTH
        y_mult = display_height/DEFAULT_DISPLAY_HEIGHT
        left_arrow_active, right_arrow_active = True, True
        if simulation_speed == len(simulation_rate)-1: right_arrow_active = False
        if simulation_speed == 0: left_arrow_active = False
        click, escape = GUI.check_click_and_escape(pygame.event.get())
        display.blit(screenshot,(0,0))
        if escape:
            return False
        GUI.message_display(x_mult,y_mult,330,60,620,100,"Simulation Menu")
        if timer > 0:
            timer -= 1
            GUI.message_display(x_mult,y_mult,330,135,620,60,save_message,40)
        should_save = GUI.draw_button(x_mult,y_mult,330,200,620,100,"Save Simulation",click,selected_colour=DARKTURQUOISE,selected="/Presets/" in save_file,disabled="/Presets/" in save_file)
        should_go_to_options = GUI.draw_button(x_mult,y_mult,330,320,620,100,"Options",click)
        GUI.draw_button(x_mult,y_mult,330,440,620,100,"Calculation rate: "+speed_name[simulation_speed],disabled=True,textSize=45)
        if GUI.draw_triangle_button(x_mult,y_mult,980,440,70,100,True,mouse_clicked=click,active=right_arrow_active):
            simulation_speed += 1
        if GUI.draw_triangle_button(x_mult,y_mult,230,440,70,100,False,mouse_clicked=click,active=left_arrow_active):
            simulation_speed -= 1
        should_go_to_main_menu = GUI.draw_button(x_mult,y_mult,330,560,620,100,"Back to Main Menu",click)
        GUI.help_button(click)
        pygame.display.update()
        clock.tick(30)
        
        if should_go_to_options:
            options(screenshot)
        elif should_save:
            timer = 20
            try:
                save(save_file)
                save_message = "Successfully saved"
            except:
                save_message = "Error"
        elif should_go_to_main_menu:
            if "/Presets/" in save_file:
                return True
            elif GUI.confirm(["Are you sure?","Unsaved changes","will be lost..."]):
                return True



def edit_pos(body,x_mult,y_mult,click,escape,zoom,offset,temp_value):
    should_save_changes = False
    if temp_value == None:
        temp_value = [0,0]
        # temp_value being the distance (absolute space) from the
        # original body position to new body position
    body_pos = (body.pos[0]/zoom+offset[0],body.pos[1]/zoom+offset[1])
    # body position on screen
    if not body.is_daddy:
        parent = body.parent_body()
        GUI.message_display(x_mult,y_mult,950,540,100,100,"relative to:",20,False)
        GUI.message_display(x_mult,y_mult,1075,540,100,100,parent.name,20,False,colour=parent.colour)
        parent_pos = (parent.pos[0]/zoom+offset[0],parent.pos[1]/zoom+offset[1])
        try:
            pygame.draw.aaline(display,WHITE,body_pos,parent_pos)
        except: pass
        # so parent body is known
    if pygame.mouse.get_pressed()[2]:
        temp_value[0] += body.pos[0] - (pygame.mouse.get_pos()[0]-offset[0])*zoom
        temp_value[1] += body.pos[1] - (pygame.mouse.get_pos()[1]-offset[1])*zoom
        body.pos[0] = (pygame.mouse.get_pos()[0]-offset[0])*zoom
        body.pos[1] = (pygame.mouse.get_pos()[1]-offset[1])*zoom
        
    GUI.message_display(x_mult,y_mult,830,350,430,100,["Move to new position","by right clicking"],35)
    try:
        GUI.message_display(x_mult,y_mult,830,450,430,100,["New orbital radius:",number_to_string(Round(body.distance_from(body.parent_body())*1000))+"km"],35)
    except: pass # would happen if editing biggest body of system
    if GUI.draw_button(x_mult,y_mult,830,590,200,60,"Done",click,textSize=45):
        should_save_changes = True
    if GUI.draw_button(x_mult,y_mult,1060,590,200,60,"Cancel",click,textSize=45):
        body.pos[0] += temp_value[0]
        body.pos[1] += temp_value[1]
        # revert body's position to its original position
        return True, None

    if should_save_changes:
        if not body.is_daddy:
            original_velocity = list(body.vel)
            parent = body.parent_body()
            theta1 = cmath.phase(complex(body.pos[0]-parent.pos[0],body.pos[1]-parent.pos[1]))
            theta2 = cmath.phase(complex(body.pos[0]-parent.pos[0]+temp_value[0],body.pos[1]-parent.pos[1]+temp_value[1]))
            body.vel = complex(body.vel[0]-parent.vel[0],body.vel[1]-parent.vel[1])/cmath.exp(complex(0,theta2-theta1))
            body.vel = [body.vel.real+parent.vel[0], body.vel.imag+parent.vel[1]]
            children = []
            body.pos[0] += temp_value[0]
            body.pos[1] += temp_value[1]
            for child in bodies:
                if child.parent_body() == body and child.name != body.name:
                    children.append(child)
            body.pos[0] -= temp_value[0]
            body.pos[1] -= temp_value[1]
            if len(children) > 0:
                if GUI.confirm(["Apply changes to","Satellites of "+body.name+"?"]):
                    for child in children:
                        child.pos[0] -= temp_value[0]
                        child.pos[1] -= temp_value[1]
                        child.vel[0] += body.vel[0]-original_velocity[0]
                        child.vel[1] += body.vel[1]-original_velocity[1]
        return True, None
    
    return False, temp_value


def edit_mass(body,x_mult,y_mult,click,escape,zoom,offset,temp_value):
    screenshot = pygame.PixelArray(display).make_surface()
    mass = body.GM/G * 1e18
    # mass of body in kg
    unit = ("N",1e24)
    # code-word for unit and actual unit
    mass_converted = number_to_string(mass/unit[1],False)
    # mass converted to that unit (the string the user will see)
    global bodies
    edited = False
    while True:
        events = pygame.event.get()
        click, escape = GUI.check_click_and_escape(events)
        if escape:
            return True, None
        display.blit(screenshot,(0,0))
        old_mass_converted = mass_converted
        mass_converted =  GUI.update_text(mass_converted,events,number=True)
        # update string according to keyboard inputs
        if mass_converted != old_mass_converted: edited = True
        # mass string has been changed so:
        if edited:
            # update numerical mass value accordingly
            try:
                mass = float(mass_converted) * unit[1]
            except:
                try:
                    mass = float(int(mass_converted)) * unit[1]
                except:
                    mass = 0
        GUI.message_display(x_mult,y_mult,330,60,620,100,"Change mass of "+body.name)
        GUI.message_display(x_mult,y_mult,0,220,620,100,"Enter desired mass:")
        GUI.draw_button(x_mult,y_mult,620,220,620,100,mass_converted,click,colour=BLACK,disabled=True)
        # draw text box containing mass converted into required units
        GUI.message_display(x_mult,y_mult,140,400,200,100,"Unit:",centred=False)
        if GUI.draw_button(x_mult,y_mult,300,380,260,100,"10^24kg",click,textSize=50,selected_colour=DARKTURQUOISE,selected=unit[0]=="N"):
            # change to this unit
            unit = ("N",1e24)
            mass_converted = number_to_string(mass/unit[1],False)
            edited = False
        if GUI.draw_button(x_mult,y_mult,590,380,260,100,"Earths",click,textSize=50,selected_colour=DARKTURQUOISE,selected=unit[0]=="E"):
            # change to this unit
            unit = ("E",MASS_OF_EARTH)
            mass_converted = number_to_string(mass/unit[1],False)
            edited = False
        if GUI.draw_button(x_mult,y_mult,880,380,260,100,"Suns",click,textSize=50,selected_colour=DARKTURQUOISE,selected=unit[0]=="S"):
            # change to this unit
            unit = ("S",MASS_OF_SUN)
            mass_converted = number_to_string(mass/unit[1],False)
            edited = False
        if GUI.draw_button(x_mult,y_mult,210,540,400,100,"Done",click) or GUI.check_enter(events):
            if mass != 0:
                body.r *= ((float(mass) * G / 1e18)/body.GM)**(1/3)
                body.GM = mass * G / 1e18
                # update official mass of body
                biggest = (0,bodies[0].GM)
                for i in range(len(bodies)):
                    if bodies[i].GM > biggest[1]:
                        biggest = (i,bodies[i].GM)
                for i in range(len(bodies)):
                    if i == biggest[0]:
                        bodies[i].is_daddy = True
                    else:
                        bodies[i].is_daddy = False
                bodies = update_mass_order()
                # update biggest body of system 
                return True, None
        if GUI.draw_button(x_mult,y_mult,670,540,400,100,"Cancel",click):
            return True, None
        GUI.help_button(click)
        pygame.display.update()
        clock.tick(30)


def edit_name(body,x_mult,y_mult,click,escape,zoom,offset,temp_value,first=False):
    screenshot = pygame.PixelArray(display).make_surface()
    new_name = body.name
    count = 0
    while True:
        events = pygame.event.get()
        click, escape = GUI.check_click_and_escape(events)
        if escape:
            return True, None
        new_name = GUI.update_text(new_name,events,False,245,25)
        display.blit(screenshot,(0,0))
        if first:
            GUI.message_display(x_mult,y_mult,330,60,620,100,"Name First Planet/Star")
        else:
            GUI.message_display(x_mult,y_mult,330,60,620,100,"Re-name \""+body.name+"\"")
        if count > 0:
            count -= 1
            GUI.message_display(x_mult,y_mult,330,124,620,100,"Name already taken",text_size=35)
        if first:
            GUI.message_display(x_mult,y_mult,0,250,620,100,"Name of first body:")
        else:
            GUI.message_display(x_mult,y_mult,0,250,620,100,"New name:")
        GUI.draw_button(x_mult,y_mult,620,250,620,100,new_name,click,colour=BLACK,disabled=True)
        if GUI.draw_button(x_mult,y_mult,210,420,400,100,"Done",click) or GUI.check_enter(events):
            for other_body in bodies:
                if (new_name == other_body.name) and not (other_body == body):
                    count = 30
                    break
            else:
                body.name = new_name
                return True, None
        if GUI.draw_button(x_mult,y_mult,670,420,400,100,"Cancel",click):
            return True, None
        GUI.help_button(click)
        pygame.display.update()
        clock.tick(30)


def edit_vel(body,x_mult,y_mult,click,escape,zoom,offset,temp_value):
    parent = body.parent_body()
    body_pos = (body.pos[0]/zoom+offset[0],body.pos[1]/zoom+offset[1])
    # position of body on screen
    mouse_pos = pygame.mouse.get_pos()
    new_vel = [(20*zoom**(-0.5))*(zoom*(mouse_pos[0]-offset[0])-body.pos[0]),
               (20*zoom**(-0.5))*(zoom*(mouse_pos[1]-offset[1])-body.pos[1])]
    pygame.draw.aaline(display,WHITE,body_pos,mouse_pos)
    # the velocity vector
    theta = cmath.phase(complex(body_pos[0]-mouse_pos[0],body_pos[1]-mouse_pos[1]))
    # angle between velocity vector and the horizontal x-axis
    length = 5*max(log10(magnitude(body_pos[0]-mouse_pos[0],body_pos[1]-mouse_pos[1])),0)
    # desired length of arrow head
    trans1 = length*cmath.exp(complex(0,theta+0.5))
    trans1 = (trans1.real,trans1.imag)
    pygame.draw.aaline(display,WHITE,mouse_pos,(mouse_pos[0]+trans1[0],mouse_pos[1]+trans1[1]))
    # draw half of arrow-head with angle 0.5 radians to the velocity vector
    trans2 = length*cmath.exp(complex(0,theta-0.5))
    trans2 = (trans2.real,trans2.imag)
    pygame.draw.aaline(display,WHITE,mouse_pos,(mouse_pos[0]+trans2[0],mouse_pos[1]+trans2[1]))
    # draw other half of arrow-head with angle 0.5 radians to the velocity vector
    GUI.message_display(x_mult,y_mult,830,400,430,100,["Right click to","confirm new velocity"],35)
    GUI.message_display(x_mult,y_mult,830,490,430,100,"Press Escape to cancel",35)
    GUI.message_display(x_mult,y_mult,830,580,430,100,["New orbital velocity:",number_to_string(magnitude(new_vel[0],new_vel[1]))+"m/s"],35)
    if not body.is_daddy:
        GUI.message_display(x_mult,y_mult,950,675,100,100,"relative to:",20,False)
        GUI.message_display(x_mult,y_mult,1075,675,100,100,parent.name,20,False,colour=parent.colour)
    if escape:
        return True, None
    elif pygame.mouse.get_pressed()[2]:
        if body.is_daddy:
            parent_vel = list(body.vel)
        else:
            parent_vel = list(body.parent_body().vel)
            if not body.is_daddy:
                children = []
                for child in bodies:
                    if child.parent_body() == body and child.name != body.name:
                        children.append(child)
                if len(children) > 0:
                    if GUI.confirm(["Apply changes to","Satellites of "+body.name+"?"]):
                        for child in children:
                            child.vel[0] += new_vel[0]/1e6+parent_vel[0]-body.vel[0]
                            child.vel[1] += new_vel[1]/1e6+parent_vel[1]-body.vel[1]
        body.vel = [new_vel[0]/1e6+parent_vel[0],new_vel[1]/1e6+parent_vel[1]]
        
        return True, None
    return False, None


def update_mass_order():
    new_list = []
    for body in bodies:
        i = 0
        try:
            while new_list[i].GM < body.GM:
                i += 1
            new_list.insert(i,body)
        except:
            new_list.append(body)
    return new_list


bodies = []
save_file = None
global_controls = [["Pause",0],["Sim Menu",0],["Add Planet",0],["Zoom In",0],
                   ["Zoom Out",0],["Speed Up",0],["Slow Down",0],
                   ["Cycle by mass",0],[["Cycle by mass","(other way)"],0]]
framerates = [25,30,50,60,120]
fps = 1
simulation_rate = [50,100,200,500,1000]
simulation_speed = 2
resolutions = ((1024, 768), (1152, 864), (1280, 720), (1280, 768), (1280, 800), (1280, 960), (1280, 1024), (1360, 768), (1600, 900), (1600, 1024), (1680, 1050), (1768, 992), (1920, 1080))
resolution = 2

def main():

    while True:

        B = [0,0]
        
        global save_file
        save_file, new_save = main_menu()

        global bodies
        # because hell no am I passing that through every function
        if new_save:
            bodies=[celestial_body([132.712,[0,0],[0,0],"First Celestial Body",SUN_COLOURS[random.randint(0,len(SUN_COLOURS)-1)],695.7])]
            bodies[0].is_daddy = True
            display.fill(BLACK)
            edit_name(bodies[0],display_width/DEFAULT_DISPLAY_WIDTH,
                      display_height/DEFAULT_DISPLAY_HEIGHT,None,
                      None,100,[display_width/2,display_height/2],None,True)
            display.fill(BLACK)
            edit_mass(bodies[0],display_width/DEFAULT_DISPLAY_WIDTH,
                      display_height/DEFAULT_DISPLAY_HEIGHT,None,
                      None,100,[display_width/2,display_height/2],None)
        else:
            bodies = load_file(save_file)
            biggest = (0,bodies[0].GM)
            # most massive planet

            for i in range(len(bodies)):
                if bodies[i].GM > biggest[1]:
                    biggest = (i,bodies[i].GM)
            # find which body has the most mass
            bodies[biggest[0]].is_daddy = True
            # meaning it's the centre of the system
        bodies = update_mass_order()
        
        tick_number = 0
        frame_number = 0
        time_warp = 1024.0
        simulations_per_frame = 200
        # number of iterations of gravitational calculations per frame
        lag  = 1/framerates[fps]

        Quit = False
        normal_mode = True
        # normal_mode is whether or not time is allowed to flow due to the use of the GUI
        temp_value = None
        selected_body = None
        # body whose trajectory should b projected
        freeze = False
        # paused
        edit_function = GUI.true
        # function which should be executed each frame to provide
        # a GUI for editing attributes of a celestial body
        
        mouse_pos = pygame.mouse.get_pos()
        focus = bodies[-1]
        # focus on bodies[0] (camera follows it in its orbit)
        zoom = 1000
        focus_offset = [display_width/2,display_height/2]
        # pixel distance from top left corner to focus body (one the camera follows)
        total_offset = [focus_offset[0]-focus.pos[0]/zoom,
                        focus_offset[1]-focus.pos[1]/zoom]
        # pixel distance from top left corner to the origin of absolute space

        this_frame = time.clock()
        clock.tick(framerates[fps])
        
        while not Quit:

            display.fill(BLACK)
            last_frame = this_frame
            this_frame = time.clock()

            went_in_menu = False
            zoom_out, zoom_in = False, False            
            add_new_planet = False
            events = pygame.event.get()
            # list of all keyboard/mouse inputs this frame

            mouse_click = pygame.mouse.get_pressed()
            old_mouse_pos = mouse_pos
            mouse_pos = pygame.mouse.get_pos()
            click, escape = GUI.check_click_and_escape(events)
            # was-click-pressed? and was-escape-pressed? this frame
            
            for event in events:
                if event.type == pygame.QUIT:
                    # x button (top-right of window) pressed
                    Quit = True
                    # so break out of loop and return to main menu
                elif event.type == pygame.KEYDOWN:
                    if edit_function == edit_pos or edit_function == edit_vel or normal_mode:
                        # then can interact with screen by panning and zooming, etc.
                        if event.key == global_controls[8][1]:
                            for i in range(len(bodies)):
                                if bodies[i] == selected_body: break
                            else:
                                i = 0
                            selected_body = bodies[(i-1)%len(bodies)]
                            selected_body.get_orbital_elements()
                            trajectory = selected_body.get_trajectory()
                        elif event.key == global_controls[7][1]:
                            for i in range(len(bodies)):
                                if bodies[i] == selected_body: break
                            else:
                                i = -1
                            selected_body = bodies[(i+1)%len(bodies)]
                            selected_body.get_orbital_elements()
                            trajectory = selected_body.get_trajectory()
                    if normal_mode:
                        # so time is flowing
                        if event.key == global_controls[6][1]:
                            time_warp /= 2
                            # slow down time if "<" pressed
                        elif event.key == global_controls[5][1]:
                            time_warp *= 2
                            # speed up time if ">" pressed
                        elif event.key == global_controls[0][1]:
                            if freeze:
                                freeze = False
                            else:
                                freeze = True
                        # toggle paused using spacebar
                        elif event.key == global_controls[1][1]:
                            Quit = pause()
                            mouse_pos = pygame.mouse.get_pos()
                            old_mouse_pos = pygame.mouse.get_pos()
                            # update mouse position so that view doesn't change
                        elif event.key == global_controls[2][1]:
                            add_new_planet = True
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 5:
                        zoom_out = True
                    elif event.button == 4:
                        zoom_in = True
                    if (event.button == 3 or event.button == 1) and normal_mode:
                        # if right click
                        contender = None
                        for i in range(len(bodies)):
                            r = max(bodies[i].r/zoom,4)
                            if (round(bodies[i].pos[0]/zoom+total_offset[0])-mouse_pos[0])**2+(round(bodies[i].pos[1]/zoom+total_offset[1])-mouse_pos[1])**2<=(r+1)**2:
                                try:
                                    if bodies[i].GM > bodies[contender].GM:
                                        contender = i
                                except: contender = i
                        if event.button == 3:
                            if contender == None:
                                pass
                            elif bodies[contender] == selected_body:
                                selected_body = None
                            else:
                                selected_body = bodies[contender]
                                selected_body.get_orbital_elements()
                                trajectory = selected_body.get_trajectory()
                                # switch selected body and calculate trajectory based on 2-body prediction
                                # if clicking on a body already selected, toggle selection off
                        elif event.button == 1:
                            if contender != None:
                                focus = bodies[contender]
                                focus_offset = [display_width/2,display_height/2]
                    elif event.button == 2 and normal_mode:
                        add_new_planet = True
                        

            if add_new_planet:
                position = [zoom*(mouse_pos[0]-total_offset[0]),
                            zoom*(mouse_pos[1]-total_offset[1])]
                new_body = celestial_body([G*random.randint(1,99)*1e5,position,[0,0],generate_new_name(),PLANET_COLOURS[random.randint(0,len(PLANET_COLOURS)-1)],4.67])
                new_body.r *= (new_body.GM/(G*1e6))**(1/3)
                random.randint(1,99)
                daddy = None
                for body in bodies:
                    if body.is_daddy:
                        daddy = body
                        break
                if daddy.GM > new_body.GM:
                    parent = new_body.parent_body()
                    v = sqrt((parent.GM+new_body.GM)/new_body.distance_from(parent))
                    phase = cmath.phase(complex(new_body.pos[0]-parent.pos[0],new_body.pos[1]-parent.pos[1]))
                    new_body.vel = [cos(phase-pi/2)*v+parent.vel[0],sin(phase-pi/2)*v+parent.vel[1]]
                else:
                    daddy.is_daddy = False
                    new_body.is_daddy = True
                selected_body = new_body
                bodies.append(new_body)
                bodies = update_mass_order()
                selected_body.get_orbital_elements()
                trajectory = selected_body.get_trajectory()
                normal_mode = True
                selected_body.calculate_priorities()
                
                
            
            keyboard = pygame.key.get_pressed()
            if edit_function == edit_pos or edit_function == edit_vel or normal_mode:
                # so can interact with screen by panning, zooming, etc.
                if keyboard[global_controls[3][1]] or zoom_in:   # "w" key is being pressed - zoom in
                    if zoom > 0.01:    # otherwise graphical glitches happen
                        zoom_centre = (zoom*(mouse_pos[0]-focus_offset[0]),zoom*(mouse_pos[1]-focus_offset[1]))
                        focus_offset[0] = zoom_centre[0]/zoom + focus_offset[0] - zoom_centre[0]/(zoom/1.1)
                        focus_offset[1] = zoom_centre[1]/zoom + focus_offset[1] - zoom_centre[1]/(zoom/1.1)
                        # change the focus offset so that the whole screen
                        # enlarges with the mouse position as the centre
                        zoom /= 1.1
                if keyboard[global_controls[4][1]] or zoom_out:   # "s" key is being pressed - zoom out
                    zoom_centre = (zoom*(mouse_pos[0]-focus_offset[0]),zoom*(mouse_pos[1]-focus_offset[1]))
                    focus_offset[0] = zoom_centre[0]/zoom + focus_offset[0] - zoom_centre[0]/(zoom*1.1)
                    focus_offset[1] = zoom_centre[1]/zoom + focus_offset[1] - zoom_centre[1]/(zoom*1.1)
                    # change the focus offset so that the whole screen moves
                    # shrinks with the mouse position as the centre
                    zoom *= 1.1
                if mouse_click[0]:  # left mouse button is being clicked
                    focus_offset[0] += mouse_pos[0] - old_mouse_pos[0]
                    focus_offset[1] += mouse_pos[1] - old_mouse_pos[1]
                    # change focus_offset to pan the screen

            if not freeze and normal_mode:
                if frame_number % 5 == 0:
                    for body in bodies:
                        body.calculate_priorities()
                for i in range(simulation_rate[simulation_speed]):
                    tick_number += 1
                    for body in bodies:
                        body.simulate_tick(time_warp/(simulation_rate[simulation_speed]*framerates[fps]),tick_number)

            if selected_body != None and not selected_body.is_daddy:
                if selected_body.parent_body() != trajectory[1]:
                    selected_body.get_orbital_elements()
                    trajectory = selected_body.get_trajectory()

            # simulate gravitational accelerations and movement of objects

            x_mult = display_width/DEFAULT_DISPLAY_WIDTH
            y_mult = display_height/DEFAULT_DISPLAY_HEIGHT
            # multipliers for the
            
            total_offset = [focus_offset[0]-focus.pos[0]/zoom,
                            focus_offset[1]-focus.pos[1]/zoom]
            # so that the camera follows the focus body
            if not normal_mode and edit_function == edit_pos and focus == selected_body and temp_value != None:
                total_offset = [total_offset[0]-temp_value[0]/zoom,total_offset[1]-temp_value[1]/zoom]
                
            if selected_body != None and (normal_mode or edit_function == edit_mass or edit_function == edit_name):
                selected_body.update_orbital_elements(selected_body.parent_body())
                trajectory = selected_body.get_trajectory()
                draw_trajectory(trajectory,display,zoom,total_offset,selected_body.e<1)
                # draw the two-body prediction of the object's trajectory

            for body in bodies:
                body.draw(display,zoom,total_offset)

            if normal_mode:
                # normal_mode being when time is flowing (or would be if not paused)
                GUI.message_display(x_mult,y_mult,5,5,400,40,
                                    "Time acceleration = "+number_to_string(time_warp)+"x faster",25,False)
                GUI.message_display(x_mult,y_mult,5,35,350,40,
                                    "1 second = "+format_time(time_warp),25,False)
                if freeze:
                    GUI.message_display(x_mult,y_mult,5,65,350,40,"Paused",25,False)
                elif time_warp/simulation_rate[simulation_speed] > 1.5e4:
                    GUI.message_display(x_mult,y_mult,5,65,400,40,"WARNING: Time acceleration very high, accuracy compromised",25,False)
                try:
                    if 1/lag/framerates[fps] < 0.75:
                        GUI.message_display(x_mult,y_mult,790,5,400,40,"Unable to keep up, time running slower",25,False)
                except: pass

            if selected_body != None and normal_mode:
                # if body selected and not editing one of its attributes
                if not selected_body.is_daddy:
                    GUI.message_display(x_mult,y_mult,720,350,100,100,"Data relative to:",20,False)
                    GUI.message_display(x_mult,y_mult,890,350,100,100,trajectory[1].name,20,False,colour=trajectory[1].colour)
                GUI.message_display(x_mult,y_mult,720,390,100,100,"Name:",25,False)
                GUI.message_display(x_mult,y_mult,915,390,100,100,
                                    selected_body.name,25,False)
                if GUI.draw_button(x_mult,y_mult,1160,382,100,41,"Edit",click,textSize=25):
                    edit_function, normal_mode = edit_name, False
                GUI.message_display(x_mult,y_mult,720,450,100,100,"Velocity:",25,False)
                try:
                    GUI.message_display(x_mult,y_mult,915,450,100,100,number_to_string(selected_body.calculate_orbital_velocity()*10**6)+"m/s",25,False)
                except:
                    GUI.message_display(x_mult,y_mult,915,450,100,100,"N/A",25,False)
                if GUI.draw_button(x_mult,y_mult,1160,442,100,41,"Edit",click,textSize=25):
                    edit_function, normal_mode = edit_vel, False
                GUI.message_display(x_mult,y_mult,720,510,100,100,"Mass:",25,False)
                GUI.message_display(x_mult,y_mult,915,510,100,100,
                                    format_mass(selected_body.GM),25,False)
                if GUI.draw_button(x_mult,y_mult,1160,502,100,41,"Edit",click,textSize=25):
                    edit_function, normal_mode = edit_mass, False
                GUI.message_display(x_mult,y_mult,720,570,100,100,"Orbital Radius:",25,False)
                try:
                    GUI.message_display(x_mult,y_mult,915,570,100,100,number_to_string(Round(selected_body.distance_from(trajectory[1])*1000))+"km",25,False)
                except:
                    GUI.message_display(x_mult,y_mult,915,570,100,100,"N/A",25,False)
                if GUI.draw_button(x_mult,y_mult,1160,562,100,41,"Edit",click,textSize=25):
                    edit_function, normal_mode = edit_pos, False
                if GUI.draw_button(x_mult,y_mult,1000,630,220,60,"Delete",click,RED,BRIGHTRED,textSize=35):
                    if len(bodies) > 1:
                        for i in range(len(bodies)):
                            if bodies[i] == selected_body:
                                del bodies[i]; break
                        # delete current body selected
                        if focus == selected_body:
                            focus = bodies[-1]
                            focus_offset = [total_offset[0]+focus.pos[0]/zoom,total_offset[1]+focus.pos[1]/zoom]
                        selected_body = None
                        biggest = (0,bodies[0].GM)
                        for i in range(len(bodies)):
                            if bodies[i].GM > biggest[1]:
                                biggest = (i,bodies[i].GM)
                        bodies[biggest[0]].is_daddy = True
                        bodies = update_mass_order()
                        # calculate new biggest body
                if GUI.draw_button(x_mult,y_mult,760,630,220,60,"Focus View",click,textSize=35):
                    for i in range(len(bodies)):
                        if bodies[i] == selected_body:
                            focus = bodies[i]; focus_offset = [display_width/2,display_height/2]; break
                            
            elif not normal_mode:
                # so an attribute of a body is being edited
                finished_editing, temp_value = edit_function(selected_body,x_mult,y_mult,click,escape,zoom,total_offset,temp_value) 
                if finished_editing:
                    edit_function, normal_mode, temp_value = GUI.true, True, None
                    elements = selected_body.get_orbital_elements()
                    trajectory = selected_body.get_trajectory()
                mouse_pos = pygame.mouse.get_pos()

            GUI.help_button(click)
            mouse_pos = pygame.mouse.get_pos()
            
            if not Quit:
                pygame.display.update()
            clock.tick(framerates[fps])
            frame_number += 1
            lag = this_frame - last_frame

            b = B
            B = [(bodies[0].pos[0]*bodies[0].GM+bodies[1].pos[0]*bodies[1].GM)/(bodies[0].GM+bodies[1].GM),(bodies[0].pos[1]*bodies[0].GM+bodies[1].pos[1]*bodies[1].GM)/(bodies[0].GM+bodies[1].GM)]
            r = ((bodies[0].pos[0]-B[0])**2+(bodies[0].pos[1]-B[1])**2)**0.5
            R = ((bodies[1].pos[0]-B[0])**2+(bodies[1].pos[1]-B[1])**2)**0.5
            M = bodies[1].GM/G; m = bodies[0].GM/G
            Epm = -G*M*m/(r)
            EpM = -G*M*m/(R)
            vB = [(bodies[0].vel[0]*bodies[0].GM+bodies[1].vel[0]*bodies[1].GM)/(bodies[0].GM+bodies[1].GM),(bodies[0].vel[1]*bodies[0].GM+bodies[1].vel[1]*bodies[1].GM)/(bodies[0].GM+bodies[1].GM)]
            v = ((bodies[0].vel[0]-vB[0])**2+(bodies[0].vel[1]-vB[1])**2)**0.5
            V = ((bodies[1].vel[0]-vB[0])**2+(bodies[1].vel[1]-vB[1])**2)**0.5
            Dt = time_warp/framerates[fps]
            print(Epm+1/2*m*v**2+EpM+1/2*M*V**2)

load_controls()
GUI.info_menu()
main()

